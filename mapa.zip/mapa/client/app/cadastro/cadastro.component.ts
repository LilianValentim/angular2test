import { Component } from '@angular/core';
import { MapaComponent } from '../mapa/mapa.component';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MapaService } from '../mapa/mapa.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
    moduleId: module.id,
    selector: 'cadastro',
    templateUrl: './cadastro.component.html'
})
export class CadastroComponent { 

    mapa: MapaComponent = new MapaComponent();
    meuForm: FormGroup;
    service: MapaService;
    route: ActivatedRoute;
    router: Router;
    mensagem: string = '';

    constructor(service: MapaService, fb: FormBuilder, route: ActivatedRoute, router: Router) {

        this.service = service;        
        
        this.route = route;
        this.router = router;

        this.route.params.subscribe(params => {

            let id = params['id'];
            
            if(id) {

                this.service
                .buscaPorId(id)
                .subscribe(
                    mapa => this.mapa = mapa, 
                    erro => console.log(erro)
                    );
            }

        });

        
        this.meuForm = fb.group({
            titulo: ['', Validators.compose([Validators.required, Validators.minLength(4)])],
            coordX: ['', Validators.required],
            coordY: ['', Validators.required],
            altura: ['', Validators.required],
            largura: ['', Validators.required],
            descricao: ['']
        });
    }

    cadastrar(event) {

        event.preventDefault();

        console.log(this.mapa);

        this.service
        .cadastra(this.mapa)
        .subscribe(res => {
            this.mensagem = res.mensagem;
            this.mapa = new MapaComponent();
            if(!res.inclusao)
            this.router.navigate(['']);
            console.log('mapa cadastrada com sucesso');
        }, erro =>{ console.log(erro);
            this.mensagem = 'Não foi possível savar a foto';
        });
    }

}