import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MapaComponent } from './mapa.component';
import { FiltroPorTitulo } from './mapa.pipes';
import { MapaService } from './mapa.service';

@NgModule({
  imports: [ CommonModule ],
  declarations: [ MapaComponent, FiltroPorTitulo ],
  exports: [ MapaComponent, FiltroPorTitulo ],
  providers: [ MapaService ]
})
export class MapaModule { }