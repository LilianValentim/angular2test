import { Component, Input, ViewEncapsulation } from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'mapa',
    templateUrl: './mapa.component.html',
    styleUrls: ['./mapa.component.css']
})
export class MapaComponent {

    @Input() titulo: string = '';
    @Input() coordX: string = '';
    @Input() coordY: string = '';
    descricao: string = '';
    @Input() altura: string = '';
    @Input() largura: string = '';
    _id: string = '';
}