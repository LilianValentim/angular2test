import { Pipe, PipeTransform } from '@angular/core';
import { MapaComponent } from './mapa.component';
 
@Pipe({
    name: 'filtroPorTitulo'
})
export class FiltroPorTitulo implements PipeTransform { 

    transform(mapas: MapaComponent[], digitado: string) {

        digitado = digitado.toLowerCase();
        return mapas.filter( mapa => mapa.titulo.toLowerCase().includes(digitado));
    }
}