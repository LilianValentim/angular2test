import { Http, Headers, Response } from '@angular/http';
import { MapaComponent } from './mapa.component';
import {Observable} from 'rxjs'; 
import { Injectable } from '@angular/core';

@Injectable()
export class MapaService {

    http: Http;
    headers: Headers;
    url: string = 'v1/fotos';

    constructor(http: Http) { 

        this.http = http;
        this.headers = new Headers();
        this.headers.append('Content-Type', 'application/json');
    }

    cadastra(mapa: MapaComponent): Observable<MensagemCadastro> {

        if (mapa._id) {
            return this.http
            .put(this.url + '/' + mapa._id, JSON.stringify(mapa), { headers: this.headers })
            .map( () => new MensagemCadastro ('Mapa alterado!', false));

        } else {
            return this.http
            .post(this.url, JSON.stringify(mapa), { headers: this.headers })
            .map( () => new MensagemCadastro ('Mapa incluído!', true));
        }
    }

    lista(): Observable<MapaComponent[]> {

        return this.http.get(this.url)
        .map(res => res.json());
    }

    remove( mapa: MapaComponent){
        return this.http.delete(this.url + '/' + mapa._id); 
    }

    buscaPorId(id:string): Observable<MapaComponent>{
        return this.http
        .get(this.url + '/' + id)
        .map(res => res.json());
    }
    
}

export class MensagemCadastro {
    

    constructor(private _mensagem: string, private _inclusao:boolean){

        this._mensagem = _mensagem;
        this._inclusao = _inclusao;

    }

    get mensagem(): string {

        return this._mensagem;
    }

    get inclusao(): boolean {

        return this._inclusao;
    }

}