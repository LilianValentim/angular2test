import { Component } from '@angular/core';
import { MapaComponent } from '../mapa/mapa.component';
import { MapaService } from '../mapa/mapa.service';

@Component({
    moduleId: module.id,
    selector: 'listagem',
    templateUrl: './listagem.component.html' 
})
export class ListagemComponent { 

    mapas: MapaComponent[] = [];
    service: MapaService;
    mensagem: string = '';

    constructor( service: MapaService ) {

        this.service = service;

        service
            .lista()
            .subscribe(mapas => {
                this.mapas = mapas;
            }, erro => console.log(erro));
    }

    remove(mapa) {

        this.service
            .remove(mapa)
            .subscribe(
                () => {

                    let novasMapas = this.mapas.slice(0);
                    let indice = novasMapas.indexOf(mapa);
                    novasMapas.splice(indice, 1);
                    this.mapas = novasMapas;
                    this.mensagem = 'Mapa removido com sucesso';
                }, 
                erro => {
                    this.mensagem = 'Não foi possível remover o mapa';
                    console.log(erro);
                }
            );
    }

}